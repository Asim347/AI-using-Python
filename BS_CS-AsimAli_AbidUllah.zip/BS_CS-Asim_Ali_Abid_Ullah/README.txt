====================================================
  AI-Powered Role-Based Dashboard System
  CSC-601 Artificial Intelligence (LAB) — Final Submission
  Institute of Management Sciences, Peshawar
====================================================

STUDENTS:   Asim Ali | Abid Ullah
PROGRAM:    BS Computer Science — 4th Semester
INSTRUCTOR: Mr. Ali Haider

----------------------------------------------------
HOW TO RUN:
----------------------------------------------------
1. Open: BS_CS-AsimAli_AbidUllah.ipynb in Jupyter Notebook
2. Click: Kernel → Restart & Run All
3. All outputs will be generated automatically

REQUIREMENTS:
  pip install -r requirements.txt

----------------------------------------------------
NOTEBOOK CONTENTS:
----------------------------------------------------
Section 1  — Introduction & Problem Statement
Section 2  — Literature Review & Research Gap
Section 3  — System Architecture & Methodology
Section 4  — Dataset Generation (2,000 records)
Section 5  — Data Preprocessing Pipeline
Section 6  — Model Training (GridSearchCV + 5-Fold CV)
Section 7  — Model Evaluation & Results
Section 8  — KPI Recommendation Engine
Section 9  — Visualization Engine (Plotly charts)
Section 10 — A/B Usability Testing (SUS, NASA-TLX)
Section 11 — Discussion & Conclusion

----------------------------------------------------
KEY RESULTS:
----------------------------------------------------
Best Model     : Random Forest
Accuracy       : 94.3%
F1-Score       : 0.942
SUS Score      : 82.4 (Excellent)
Time-to-Insight: -38% improvement
Cognitive Load : -40% reduction
====================================================
